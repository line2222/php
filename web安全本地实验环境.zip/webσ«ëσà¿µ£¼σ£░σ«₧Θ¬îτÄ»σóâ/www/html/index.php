<a href="/code_inject">code_inject</a>
<br />
<a href="/lfi">local file include</a>
