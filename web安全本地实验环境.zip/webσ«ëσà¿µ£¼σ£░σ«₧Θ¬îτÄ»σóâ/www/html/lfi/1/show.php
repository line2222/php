<?php
echo "This is show.php";
echo "<br>";
echo "<a href='./index.php?page=show.php'>show</a>";
echo "<br>";
echo "<a href='./upload.html'>upload pic</a>";
?>