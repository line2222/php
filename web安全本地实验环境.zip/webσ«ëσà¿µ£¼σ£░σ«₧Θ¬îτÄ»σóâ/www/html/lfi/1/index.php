<?php

if ($_GET['page']) {  
include($_GET['page']);  
} else {  
include "show.php";  
}
