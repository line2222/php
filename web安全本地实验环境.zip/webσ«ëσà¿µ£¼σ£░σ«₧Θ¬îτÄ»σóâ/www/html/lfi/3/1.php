<?php
echo file_get_contents("./action/./../uploads/20160726062336888.png")
?>
