<?php
$cmd = $_GET['cmd'];
system("ping ".$cmd);
?>
