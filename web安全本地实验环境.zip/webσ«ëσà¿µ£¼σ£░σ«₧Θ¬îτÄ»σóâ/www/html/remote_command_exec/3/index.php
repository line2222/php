<?php
$cmd = $_GET['cmd'];
system("ping -n ".$cmd);
?>
